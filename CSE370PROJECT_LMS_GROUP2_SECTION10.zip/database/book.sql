-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2024 at 09:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `ISBN` int(10) NOT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `Publisher` varchar(50) DEFAULT NULL,
  `Year` varchar(50) DEFAULT NULL,
  `Location` varchar(11) NOT NULL,
  `Availability` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`ISBN`, `Title`, `Publisher`, `Year`, `Location`, `Availability`) VALUES
(1, 'harry potter', 'PEARSON', '2006', 's-12', 8),
(2, 'rings', 'TARGET67', '2010', 's-13', 8),
(3, 'machine learning', 'NITC', '2018', 's-14', 0),
(4, 'java script', 'NITC', '2018', 'h-17', 0),
(5, 'pythone', 'y', '2014', 'j-98', 3),
(6, 'Feluda', 'X', '2010', 'h-21', 0),
(7, 'Discrete Structures', 'Pearson', '2010', 'k-19', 1),
(8, 'Database Processing', 'Prentice Hall', '2013', 'a-12', 2),
(9, 'Computer System Architecture', 'Prentice Hall', '2015', 'k-23', 9),
(10, 'C learning', 'Prentice Hall', '2009', 'g-9', 9),
(11, 'Atomic and Nuclear Systems', 'Pearson India ', '2017', 'j-12', 4),
(12, 'The PlayBook', 'Stinson', '2010', 'k-10', 3),
(13, 'General Theory of Relativity', 'Pearson India ', '2012', 'k-17', 11),
(14, 'Heat and Thermodynamics', 'Pearson', '2013', 'k-19', 9),
(15, 'Machine Design', 'Pearson India ', '2012', 'k-19', 9),
(16, 'Nuclear Physics', 'Pearson India ', '1998', 'a-13', 8),
(17, 'Operating System', 'Pearson India ', '1990', 'k-18', 0),
(18, 'Theory of Machines', 'Pearson', '1992', 'k-19', 0),
(29, 'we', 'ak', '33', '', 33),
(30, 'deep', 'ak ', '2014', '', 7),
(31, 'bcd', 'akc', '2024', '', 3),
(32, 'abcd', 'akg', '2023', '', 4),
(33, 'abcde', 'mk ', '2020', '', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`ISBN`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `ISBN` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
