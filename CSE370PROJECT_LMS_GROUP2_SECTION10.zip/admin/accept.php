<?php
require('dbconn.php');

$ISBN = $_GET['id1'];
$rollno = $_GET['id2'];

// Assume all students are treated the same way as 'GEN' or 'OBC'
// You can modify this part based on your actual business logic
$sql = "SELECT * FROM LMS.record WHERE RollNo='$rollno'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Check if the student exists in the record table
if (!$row) {
    echo "<script type='text/javascript'>alert('Student not found')</script>";
    header("Refresh:0.01; url=issue_requests.php", true, 303);
    exit;
}

$sql1 = "UPDATE LMS.record SET Date_of_Issue=curdate(), Due_Date=date_add(curdate(), INTERVAL 60 DAY), Renewals_left=1 WHERE ISBN='$ISBN' AND RollNo='$rollno'";
if ($conn->query($sql1) === TRUE) {
    $sql3 = "UPDATE LMS.book SET Availability=Availability-1 WHERE ISBN='$ISBN'";
    $conn->query($sql3);
} else {
    $sql2 = "UPDATE LMS.record SET Date_of_Issue=curdate(), Due_Date=date_add(curdate(), INTERVAL 180 DAY), Renewals_left=1 WHERE ISBN='$ISBN' AND RollNo='$rollno'";
    
    if ($conn->query($sql2) === TRUE) {
        $sql4 = "UPDATE LMS.book SET Availability=Availability-1 WHERE ISBN='$ISBN'";
        $conn->query($sql4);
    }
}

header("Refresh:0.01; url=issue_requests.php", true, 303);
?>
